package nidio.dev.dockerspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerspringApplication.class, args);
	}

}
