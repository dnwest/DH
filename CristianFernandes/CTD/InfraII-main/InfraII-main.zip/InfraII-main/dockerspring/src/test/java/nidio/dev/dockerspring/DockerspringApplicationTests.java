package nidio.dev.dockerspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
