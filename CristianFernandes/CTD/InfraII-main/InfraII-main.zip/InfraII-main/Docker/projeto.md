Docker 1:
    OpenJDK
    Maven
    Spring - boot e web
    H2
    Log4J

    JUnit

Docker 2:
    App web
    REACT
    BootStrap
