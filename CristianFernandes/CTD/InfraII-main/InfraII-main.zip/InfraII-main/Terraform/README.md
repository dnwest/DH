Faça o download do arquivo: 

https://drive.google.com/drive/folders/1H1dOF7eAZNyjseIGqAPNuDQ_XS-snSoS?usp=sharing

Crie uma pasta chamada terraform no disco C:\

![Pasta](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/pasta%20terraform.png?raw=true)

Copie o arquivo para a pasta que você criou: 

![Terraform exe](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/APP.png?raw=true)

Digite *variáveis de ambiente* no menu iniciar:

![menu iniciar](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/menu%20iniciar.png?raw=true)

Clique em Variáveis de Ambiente: 

![abrir variaveis](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/editar%20variaveis.png?raw=true)

Clique em Path depois em Editar:

![abrir path](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/adicionar%20variavel.png?raw=true)

Clique em Novo e depois digite *C:\terraform* ou o local onde estiver o arquivo do terraform 

![adicionar terraform ao path](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/variavel%20terraform.png?raw=true)

No PowerShell use os comandos abaixo:
```
terraform --version
```

