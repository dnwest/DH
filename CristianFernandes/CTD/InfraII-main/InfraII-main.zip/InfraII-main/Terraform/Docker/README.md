No PowerShell use os comandos abaixo:
```
mkdir aula-terraform-docker
```
```
cd aula-terraform-docker
```
crie o arquivo main.tf ou baixe o arquivo a pasta do projeto:

https://github.com/nidiodolfini/InfraII/blob/main/Terraform/Docker/main.tf

![main tf](https://github.com/nidiodolfini/InfraII/blob/main/Terraform/img/main%20tf.png?raw=true)

```
terraform init
```
```
terraform apply
```
acesse pelo navegador: http://localhost:8000/
